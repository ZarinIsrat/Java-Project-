import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;

class Signup extends JFrame implements ActionListener {
	Loginaccess la;

	ResultSet rs;

	JButton SUBMIT, DECLINE;

	JLabel snUp, fName, uName, pWord, phNo, eMal;

	JTextField fullname, uname, phone, email;

	JPasswordField password;

	Signup() {
		la = new Loginaccess();

		snUp = new JLabel();
		snUp.setText("SIGNUP");

		fName = new JLabel();
		fName.setText("Full Name:");
		fullname = new JTextField(30);

		uName = new JLabel();
		uName.setText("Username:");
		uname = new JTextField(30);

		pWord = new JLabel();
		pWord.setText("Password:");
		password = new JPasswordField();

		phNo = new JLabel();
		phNo.setText("Phone:");
		phone = new JTextField(30);

		eMal = new JLabel();
		eMal.setText("Email:");
		email = new JTextField(30);

		SUBMIT = new JButton("SUBMIT");
		DECLINE = new JButton("DECLINE");

		snUp.setBounds(400, 50, 100, 30);

		fullname.setBounds(300, 110, 200, 30);
		fName.setBounds(200, 110, 200, 30);

		uname.setBounds(300, 160, 200, 30);
		uName.setBounds(200, 160, 200, 30);

		password.setBounds(300, 210, 200, 30);
		pWord.setBounds(200, 210, 100, 30);

		phone.setBounds(300, 260, 200, 30);
		phNo.setBounds(200, 260, 100, 30);

		email.setBounds(300, 310, 200, 30);
		eMal.setBounds(200, 310, 100, 30);

		SUBMIT.setBounds(300, 350, 100, 30);
		SUBMIT.addActionListener(this);

		DECLINE.setBounds(400, 350, 100, 30);
		DECLINE.addActionListener(this);

		add(snUp);

		add(fullname);
		add(fName);

		add(uname);
		add(uName);

		add(password);
		add(pWord);

		add(phone);
		add(phNo);

		add(email);
		add(eMal);

		add(SUBMIT);
		add(DECLINE);

		setSize(800, 600);
		setTitle("SIGNUP");

		setLayout(null);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == SUBMIT) {
			if(register()) {
				new Homepage(uname.getText());
				this.hide();				
			}
		} else if (ae.getSource() == DECLINE) {
			new LoginDemo();
			this.hide();
		}
	}
	
	boolean register() {
		String fn = fullname.getText();
		String un = uname.getText();
		String pw = password.getText();
		String phn = phone.getText();
		String mail = email.getText();
		
		if (!fn.isEmpty() && !un.isEmpty() && !pw.isEmpty() && !phn.isEmpty() && !mail.isEmpty()) {
			String sql = "INSERT INTO userinfo VALUES ('"+fn+"','"+un+"','"+pw+"','"+phn+"','"
					+mail+"', 0)";
			la.exQuery(sql);
			return true;
		}
		return false;
	}
}