import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Details extends JFrame implements ActionListener {
	Loginaccess ld;
	
	ResultSet rs;
	
	String fullName,userName, phone, mail, balance ;
	
	JLabel ttlT, fName, mailT, phnT, balT;
	
	JButton BACK;

	Details(String userName) {
		ld = new Loginaccess();
		this.userName = userName;
		setInfo(userName);

		ttlT = new JLabel();
		ttlT.setText("Profile");
		ttlT.setBounds(400, 10, 500, 60);
		add(ttlT);
		
		BACK = new JButton("BACK");
		BACK.setBounds(250, 450, 400, 50);

		fName = new JLabel("Full Name : "+fullName);
		mailT = new JLabel("Email : "+mail);
		phnT = new JLabel("Phone : "+phone);
		balT = new JLabel("Balance : "+balance);
		
		add(fName);
		add(mailT);
		add(mailT);
		add(phnT);
		add(balT);
		
		add(BACK);
		fName.setBounds(20, 100, 500, 50);
		mailT.setBounds(20, 150, 500, 50);
		phnT.setBounds(20, 200, 500, 50);
		balT.setBounds(20, 250, 500, 50);
		
		BACK.addActionListener(this);

		setLayout(null);
		setSize(800, 600);
		setLocationRelativeTo(null);
		setTitle("PROFILE");
		setVisible(true);
	}

	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == BACK) {
			new Homepage(userName);
			dispose();
		}
	}
	
	void setInfo(String userName) {
		String sql = "select * from userinfo where uName = '"+userName+"'";
		rs = ld.getResult(sql);
		
		try {
			while(rs.next()) {
				fullName = rs.getString("fullName");
				phone = rs.getString("phone");
				mail = rs.getString("mail");
				balance = rs.getString("balance");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
