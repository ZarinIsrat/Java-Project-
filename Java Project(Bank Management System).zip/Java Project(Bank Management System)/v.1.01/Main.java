class Main {
	public static void main(String arg[]) {
		LoginDemo frame = new LoginDemo();
	}
}