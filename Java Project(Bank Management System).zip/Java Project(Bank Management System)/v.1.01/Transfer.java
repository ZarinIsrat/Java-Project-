import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Transfer extends JFrame implements ActionListener {

	Loginaccess ld;
	
	ResultSet rs;
	
	String userName, tuserName;
	
	JLabel titlelabel, unamelabel, tunamelabel, amountlabel;

	JButton OK,CANCEL;
	
	JTextField unametext, amounttext,tunametext;

	int balance=0, amount = 0;

	Transfer(String uName) {
		
		titlelabel = new JLabel();
		this.userName = uName;
		titlelabel.setText(" ENTER TRANSFER AMAOUNT AND ACCOUNT NUMBER");
		
		unamelabel= new JLabel();
		unamelabel.setText(" ACCOUNT USER NAME: ");
		
		tunamelabel= new JLabel();
		tunamelabel.setText(" RECEIVER USER NAME: ");
		
		amountlabel = new JLabel();
		amountlabel.setText(" AMAOUNT: ");
		
		unametext = new JTextField(25);
		amounttext = new JTextField(25);
		tunametext = new JTextField(25);
		
		titlelabel.setBounds(250, 50, 500, 50);
		unamelabel.setBounds(70, 150, 500, 50);
		tunamelabel.setBounds(70, 200, 500, 50);
		amountlabel.setBounds(70, 250, 500, 50);
		
		unametext.setBounds(230, 150, 400, 30);
		tunametext.setBounds(230, 200, 400, 30);
		amounttext.setBounds(230, 250, 400, 30);
		
		OK = new JButton("OK");
		OK.addActionListener(this);
		OK.setBounds(230, 300, 400, 30);
		// WITHDRAW.addActionListener(this);
		
		CANCEL = new JButton("CANCEL");
		CANCEL.addActionListener(this);
		CANCEL.setBounds(230, 330, 400, 30);
		// WITHDRAW.addActionListener(this);
		
		add(titlelabel);
		add(unamelabel);
		add(tunamelabel);
		add(amountlabel);
		add(unametext);
		add(tunametext);
		add(amounttext);
		
		add(OK);
		add(CANCEL);
		
		setSize(800, 600);

		setLayout(null);
		setVisible(true);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("TRANSFER");
	}

	public void actionPerformed(ActionEvent ae) {

		if (ae.getSource() == OK) {
				try {
				transection();
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, e.getMessage());
				}
		}
		
		if (ae.getSource() == CANCEL) {
			new Homepage(userName);
			this.dispose();
		}
	}

	public void transection() {
		if (!unametext.getText().isEmpty() && !amounttext.getText().isEmpty()) {
			String sql = "select balance from userinfo where uName = '"+userName+"'";
			rs = ld.getResult(sql);
			try {
				while (rs.next()) {
					balance = rs.getInt("balance");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			userName = unametext.getText();
			tuserName = tunametext.getText();
			//amount = Integer.parseInt(amounttext.getText());
			withdraw(userName, amount);
			deposit(tuserName, amount);
			// if(new Withdraw().transection()){
				// ld.Deposit(amount);
				// sql = "UPDATE userInfo SET balance = "+balance+"WHERE uName = '"+userName+"'";
				// ld.exQuery(sql);
				// JOptionPane.showMessageDialog(null, "Money Transfered");
				// return true;
		 }
		else
			JOptionPane.showMessageDialog(null, "Transfer Failed");
	}
	
	
	public void withdraw(String userName, int amount) {
		
			String sql = "select balance from userinfo where uName = '"+userName+"'";
			rs = ld.getResult(sql);
			try {
				while (rs.next()) {
					balance = rs.getInt("balance");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			amount = Integer.parseInt(amounttext.getText());
			if(balance>=amount){
				balance-=amount;
				sql = "UPDATE userinfo SET balance = "+balance+" WHERE uName = '"+userName+"'";
				ld.exQuery(sql);
			}
		}
	
	public void deposit(String tuserName, int amount) {
		
			String sql = "select balance from userinfo where uName = '"+tuserName+"'";
			rs = ld.getResult(sql);
			try {
				while (rs.next()) {
					balance = rs.getInt("balance");
				}
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
			amount = Integer.parseInt(amounttext.getText());
			balance = balance + amount;
			sql = "UPDATE userinfo SET balance = "+balance+" WHERE uName = '"+tuserName+"'";
			ld.exQuery(sql);
			JOptionPane.showMessageDialog(this,"Deposit Successful");
		

	}
}