import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

//DONE
class LoginDemo extends JFrame implements ActionListener {
	JButton LOGIN, CANCEL, SIGNUP;

	Loginaccess ld;
	ResultSet rs;

	int flag = 1;
	JLabel uNameLabel, uPassLabel;
	JTextField uNameTF;
	JPasswordField uPassTF;

	LoginDemo() {
		ld = new Loginaccess();
		
		uNameLabel = new JLabel();
		uNameLabel.setText("Username:");
		uNameLabel.setBounds(200, 100, 100, 30);
		
		uNameTF = new JTextField(25);
		uNameTF.setBounds(300, 100, 200, 30);

		uPassLabel = new JLabel();
		uPassLabel.setText("Password:");
		uPassLabel.setBounds(200, 150, 100, 30);
		
		uPassTF = new JPasswordField();
		uPassTF.setBounds(300, 150, 200, 30);
		
		LOGIN = new JButton("LOGIN");
		LOGIN.setBounds(300, 200, 100, 30);
		LOGIN.addActionListener(this);
		
		CANCEL = new JButton("CANCEL");
		CANCEL.setBounds(400, 200, 100, 30);
		CANCEL.addActionListener(this);

		SIGNUP = new JButton("SIGN UP");
		SIGNUP.addActionListener(this);		
		SIGNUP.setBounds(670, 15, 100, 30);

		add(uNameLabel);
		add(uNameTF);
		add(uPassLabel);
		add(uPassTF);
		add(LOGIN);
		add(CANCEL);
		add(SIGNUP);
		
		setTitle("LOGIN FORM");
		setSize(800, 600);
		setLayout(null);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == SIGNUP) {
			new Signup();
			this.dispose();
		} else if (ae.getSource() == LOGIN) {
			if (isValidUser()) {
				new Homepage(this.uNameTF.getText());
				this.dispose();				
			} else {
				JOptionPane.showMessageDialog(null, "Wrong UserName/Password");
			}
		} else if (ae.getSource() == CANCEL) {
			uNameTF.setText(null);
			uPassTF.setText(null);
		}
	}
	
	// check if the user is VALID or not
	boolean isValidUser() {
		String sql = "select uName, password from userinfo where uName = '"+uNameTF.getText()+"'";
		rs = ld.getResult(sql);
		
		try {
			while(rs.next()) {
				String password = rs.getString("password");
				
				if (password.equals(uPassTF.getText())) {
					return true;
				}
			}
		} catch (SQLException e) {}
		return false;
	}
}






/*
 * CREATE TABLE userInfo ( fullName char(50), uName char(20), password char(20), phone char(15), mail char(30), `balance` INT(10) DEFAULT '0')
 * 
 * 
 */


