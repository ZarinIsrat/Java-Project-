import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Deposit extends JFrame implements ActionListener {
	
	Loginaccess ld;
	
	ResultSet rs;
	
	String userName;
	
	JLabel titlelabel, unamelabel, amountlabel;
	
	JButton OK, CANCEL;
	
	JTextField unametext, amounttext;
	
	int balance = 0;

	public Deposit(String userName) {
		ld = new Loginaccess();
		this.userName = userName;
		// this.balance = a;

		titlelabel = new JLabel();
		titlelabel.setText(" ENTER DEPOSIT AMAOUNT AND ACCOUNT NUMBER");
		unamelabel = new JLabel();
		unamelabel.setText(" ACCOUNT USER NAME ");
		amountlabel = new JLabel();
		amountlabel.setText(" AMAOUNT");
		unametext = new JTextField(25);
		amounttext = new JTextField(25);
		titlelabel.setBounds(250, 50, 500, 50);
		unamelabel.setBounds(70, 150, 500, 50);
		amountlabel.setBounds(70, 200, 500, 50);
		unametext.setBounds(230, 150, 400, 30);
		amounttext.setBounds(230, 200, 400, 30);
		OK = new JButton("OK");
		OK.addActionListener(this);
		OK.setBounds(230, 250, 400, 30);
		// WITHDRAW.addActionListener(this);
		OK.setEnabled(true);
		CANCEL = new JButton("CANCEL");
		CANCEL.addActionListener(this);
		CANCEL.setBounds(230, 280, 400, 30);
		// WITHDRAW.addActionListener(this);
		CANCEL.setEnabled(true);
		add(titlelabel);
		add(unamelabel);
		add(amountlabel);
		add(unametext);
		add(amounttext);
		add(OK);
		add(CANCEL);
		setSize(800, 600);

		setLayout(null);
		setLocationRelativeTo(null);
		setTitle("DEPOSIT");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == OK) {
			userName = unametext.getText();
			transection();
		} else if (ae.getSource() == CANCEL) {
			new Homepage(userName);
			dispose();
		}
	}

	void transection() {
		if (userName.equals(unametext.getText()) && !unametext.getText().isEmpty() && !amounttext.getText().isEmpty()) {
			String sql = "select balance from userinfo where uName = '" + userName + "'";
			rs = ld.getResult(sql);
			try {
				while (rs.next()) {
					balance = rs.getInt("balance");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			int amount = Integer.parseInt(amounttext.getText());
			balance = balance + amount;
			sql = "UPDATE userinfo SET balance = "+balance+" WHERE uName = '"+userName+"'";
			ld.exQuery(sql);
			JOptionPane.showMessageDialog(this,"Deposit Successful");
		}

	}
}
