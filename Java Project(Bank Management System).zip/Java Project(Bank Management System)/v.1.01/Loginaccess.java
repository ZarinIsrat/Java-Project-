import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Loginaccess{
    Connection conn;
    Statement stmt;
    ResultSet rs;
    
    String url = "jdbc:mysql://localhost:3306/bank78";
	String user = "root";
	String password = "";

	ResultSet resultSet;
		
    public Loginaccess(){
    	try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(url, user, password);
			stmt = conn.createStatement();
		} catch (SQLException e) {
		} catch (InstantiationException e) {
		} catch (IllegalAccessException e) {
		} catch (ClassNotFoundException e) {
		}
    }
    
	protected ResultSet getResult(String query) {
		try {
			resultSet = stmt.executeQuery(query);
		} catch (SQLException e) {
		}

		return resultSet;
	}

	protected boolean exQuery(String _query) {
		try {
			stmt.execute(_query);
			return true;
		} catch (SQLException e) {
			return false;
		}
	}

	protected void close() throws SQLException {
		if (resultSet != null) {
			resultSet.close();
			stmt.close();
		}
	}
}


