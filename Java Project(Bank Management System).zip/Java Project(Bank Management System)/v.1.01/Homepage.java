import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class Homepage extends JFrame implements ActionListener {
	
	String userName; //get from loginPage
	int amount;
	
	JLabel label1;
	JButton PROFILE, TRANSFER, DEPOSIT, WITHDRAW, LOGOUT;

	Homepage(String userName) {
		this.userName = userName;
		
		label1 = new JLabel();
		label1.setText("WELCOME , "+userName.toUpperCase());
		
		PROFILE = new JButton("PROFILE");
		WITHDRAW = new JButton("WITHDRAW");
		DEPOSIT = new JButton("DEPOSIT");
		TRANSFER = new JButton("TRANSFER");
		LOGOUT = new JButton("LOG OUT");
		
		label1.setBounds(300, 50, 500, 50);
		PROFILE.setBounds(150, 200, 500, 30);
		WITHDRAW.setBounds(150, 230, 500, 30);
		DEPOSIT.setBounds(150, 260, 500, 30);
		TRANSFER.setBounds(150, 290, 500, 30);
		LOGOUT.setBounds(150, 320, 500, 30);
		
		LOGOUT.setForeground(Color.RED);
		
		PROFILE.addActionListener(this);
		WITHDRAW.addActionListener(this);
		DEPOSIT.addActionListener(this);
		TRANSFER.addActionListener(this);
		LOGOUT.addActionListener(this);
		
		add(label1);
		add(PROFILE);
		add(WITHDRAW);
		add(DEPOSIT);
		add(TRANSFER);
		add(LOGOUT);

		setLayout(null);
		setVisible(true);
		setSize(800, 600);
		setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("HOME");
	}

	public void actionPerformed(ActionEvent ae) {
		this.hide();
		if (ae.getSource() == PROFILE) {
			new Details(userName);
			//dispose();
		} else if (ae.getSource() == DEPOSIT) {
			new Deposit(userName);
			//dispose();
		} else if (ae.getSource() == WITHDRAW) {
			new Withdraw(userName);
			//dispose();
		} else if (ae.getSource() == LOGOUT) {
			new LoginDemo();
			//dispose();
		}
		else if(ae.getSource() == TRANSFER){
			new Transfer(userName);
		}
	}

}